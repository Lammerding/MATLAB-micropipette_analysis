%MPAv7.m
% Last modified: 11/10/2016
% Calls the following function(s): threshIt.m
% Description: This program reads in a czi file of a micropipette aspiration experiment.
%   The user performs a manual mask alignment and then thresholds the nuclear signal in each pocket in order to get an accurate measurement of the nuclear protrusion length.
%   By selecting a threshold value of >=245 the event will be excluded and
%   the output file will contain zeros for this pocket.

% Supporting Files:
    % Pipettedevice mask crop GF.tif
    % Bioformats_package.jar
    % bfCheckJavaMemory.m
    % bfCheckJavaPath.m
    % bfGetPlane.m
    % bfGetReader.m
    % getkey.m
    % threshIt.m

clear
close all
opengl SOFTWARE % To correct text display issue with plot axes

mask_dx = 92; % Default:92 for 'pipettedevice mask crop GF.tif'; was 123 with old mask; 112 for 'pipettedevice mask2 crop 061016 GF.tif'; open in image J, dx is distance from left mask image edge to start of micropipettes
mask_dy = 56; % Default:52 or 54 for 'pipettedevice mask crop GF.tif', 56 for 'pipettedevice mask2 crop 061016 GF.tif'; distance in pixels from top of mask to middle of 1st pipette (from the top)
clearframe = 2; % Frame with fewest cells (helps the mask alignment)
upipStart(1:18) = 92; % Distance in pixels from left edge of mask to u-pipette entrance. Default: 92 for 'pipettedevice mask crop GF.tif' [same as mask_dx]? 112 for 'pipettedevice mask2 crop 061016 GF.tif'
Scale = 0.325;    % Pixel conversion: um/pixel (0.325x corresponds to 20x)
brightBoost = 1; % Default: 1
DNABoost = 4; % Default: 3
nthFrame = 10; % Play every nth frame during playback
frameFromEnd = 3; % Default: 3, the nth frame from the end, used by the user to set the nuclear threshold. Chosen based on frame where a cell is likely to be in the pocket. 

BF  = 1; % Channel number in stacks
DNA = 2; % Channel number in stacks
Ch3 = 3; % Channel number in stacks
Ch4 = 4; % Channel number in stacks

int_threshold = 1000; % Intensity threshold for calculation
min_area_object = 10;
radius = 2;

% Select file/s
[filename, pathname]=uigetfile({'*.czi;*.lsm;*.tif',...
    'Zeiss Files (*.czi,*.lsm,*.tif)'},'Select any file in the folder', 'MultiSelect', 'on');
cd(pathname)
filename = cellstr(filename);
i = 1;

[pathstr, name, ext] = fileparts(filename{i});
reader = bfGetReader(filename{i});
omeMeta = reader.getMetadataStore();
stackSizeX = omeMeta.getPixelsSizeX(0).getValue(); % Image width, pixels
stackSizeY = omeMeta.getPixelsSizeY(0).getValue(); % Image height, pixels
stackSizeZ = omeMeta.getPixelsSizeZ(0).getValue(); % Number of Z slices
stackSizeT = omeMeta.getPixelsSizeT(0).getValue(); % Number of time points
stackSizeC = omeMeta.getPixelsSizeC(0).getValue(); % Number of channels
positionSize = omeMeta.getImageCount(); % Number of positions

testframe = stackSizeT-(frameFromEnd-1); % The testframe is the frame used to set the threshold for the nuclear signal. 

%LSM/CZI vs TIF
if ext == '.lsm' | ext == '.czi'
    cameramodel = omeMeta.getDetectorModel(0,0); % Camera Model
    cameramodel = char(cameramodel);
    bit_depth_file = omeMeta.getPixelsSignificantBits(0).getValue(); % Bit bepth of file
    
    % Select bit depth based on camera model
    switch cameramodel
        case 'PvCamCoolSNAP_KINO'
            bit_depth_camera = 14;
        case 'PvCamCoolSNAP_HQ'
            bit_depth_camera = 12;
        otherwise
            bit_depth_camera = 16;
    end
    
    % Calculate correction factor for lower bit file in 16bit czi
    if bit_depth_file > bit_depth_camera
        intensity_factor = 2^(bit_depth_file-bit_depth_camera);
    else
        intensity_factor = 1;
    end
else
    intensity_factor = 1;
end

for q = 1:positionSize
    % Define which series to read
    reader.setSeries(q-1);
    
    % Initiate image matrices
    img_channels=zeros(stackSizeY, stackSizeX, stackSizeT, stackSizeC, 'double');
    %DNA_im=zeros(stackSizeY, stackSizeX, stackSizeT, 'double');
    
    %% Write images to matrix
    for ii = 1:stackSizeT
        for j = 1:stackSizeC
            count = j+((ii-1)*stackSizeC);
            frame = bfGetPlane(reader, count); %read frame
            img_channels(:,:,ii,j) = frame; %write to stack
        end
    end
    %%
    % Adjust image intensity based on lower bit image in higher bit file
    img_channels = immultiply(img_channels, intensity_factor);
    img_channels(:,:,:,BF) = img_channels(:,:,:,BF) .* brightBoost; 
    img_channels(:,:,:,DNA) = img_channels(:,:,:,DNA) .* DNABoost;
        
    % Calculate angle
    BF_mean = img_channels(:,:,clearframe,BF);
    
    mask_im = imread('pipettedevice mask crop GF.tif'); % Reads in the mask
    y1 = 1;
    y2 = size(img_channels,1);
    
    mask_im_temp = uint16(zeros(size(BF_mean)));
    mask_y1 = (size(BF_mean,1)/2) - (size(mask_im,1)/2);
    mask_y2 = mask_y1 + size(mask_im,1);
    mask_x1 = (size(BF_mean,2)/2) - (size(mask_im,2)/2);
    mask_x2 = mask_x1 + size(mask_im,2);
    mask_im_temp(mask_y1:mask_y2-1,mask_x1:mask_x2-1) = mask_im;
    
    delx = mask_x2 - mask_x1 - 1;
    dely = mask_y2 - mask_y1 - 1;
    
    figure(1)
    imshowpair(BF_mean, mask_im_temp,'Scaling','joint');
    title('Manual Mask Alignment','fontsize',14)
%     xlabel('Click left edge of top micropipette with left mouse button to set.\nIf mask is correct, click right mouse button to continue.\n If the mask is rotationally misaligned, click left edge of top micropipette with left mouse button and then the left edge of the bottom micropipette with the middle mouse button. Right click when done.','fontsize',8)
    
    button = 0;
    
    while button ~= 3
        [mask_x1, mask_y1, button] = ginput(1);
        if button == 3
            break;
        end
        if button == 1
            mask_x1 = round(mask_x1);
            mask_y1 = round(mask_y1-mask_dy);
            mask_x2 = mask_x1 + delx;
            mask_y2 = mask_y1 + dely;
            mask_im_temp = uint16(zeros(size(BF_mean)));
            mask_im_temp(mask_y1:mask_y2,mask_x1:mask_x2) = mask_im;
            figure(1)
            imshowpair(BF_mean, mask_im_temp,'Scaling','joint');
        else
        end
        % Use middle mouse button to perform rotation
        [mask_x2shift, mask_y2shift,button] = ginput(1);
        if button == 2
            theta_click = atan2(mask_x2shift-mask_x1, mask_y2shift-mask_y1)*(180/pi)*-1;
            img_channels = imrotate(img_channels,theta_click,'bicubic','crop');
            BF_mean = img_channels(:,:,clearframe,BF);
        elseif button == 1
            mask_x1 = round(mask_x2shift);
            mask_y1 = round(mask_y2shift-mask_dy);
            mask_x2 = mask_x1 + delx;
            mask_y2 = mask_y1 + dely;
        else
        end
        mask_im_temp = uint16(zeros(size(BF_mean)));

        
        mask_im_temp(mask_y1:mask_y2,mask_x1:mask_x2) = mask_im;
        figure(1)
        imshowpair(BF_mean, mask_im_temp,'Scaling','joint');
    end
    
    figure(1)
    imshowpair(BF_mean, mask_im_temp,'Scaling','joint');
    title('Manual Mask Alignment','fontsize',14)
    hold on;
    button = 0;
    x1_corr = mask_x1 + mask_dx;
    line([x1_corr,x1_corr],[y1,y2],'Color','y','LineWidth',2)
    hold off
    
    % Crop the image to focus on the pockets. Use img_crop for rest of the
    % program when possible.
    masksize = size(mask_im);
    for p = 1:stackSizeT
        img_cropi(:,:,p) = uint8(img_channels(:,:,p,DNA)./256);
        img_crop(:,:,p) = imcrop(img_cropi(:,:,p), [mask_x2-masksize(2) mask_y2-masksize(1) masksize(2)-20 masksize(1)]);
        img_crop(:,:,p) = im2uint8(img_crop(:,:,p));
        
        img_cropiBF(:,:,p) = uint8(img_channels(:,:,p,BF)./256);
        img_cropBF(:,:,p) = imcrop(img_cropiBF(:,:,p), [mask_x2-masksize(2) mask_y2-masksize(1) masksize(2)-20 masksize(1)]);
        img_cropBF(:,:,p) = im2uint8(img_cropBF(:,:,p));
    end
    
    testimage = img_crop(:,:,testframe);
    
    Thr_x = mean(mean(testimage)); %% Apply a starting threshold value
    
    [crop_h, crop_w, crop_t] = size(img_crop);
    inc = (crop_h-1)/18;
    
    y_top = 1;
    
    for kk = 1:18
        y_bottom = y_top+inc;
        
        Button = 0;
        
        % Compute the thresholds based on the 'testframe' (i.e., when the cells to
        % be analyzed are in the pockets and store them in an array 1:18)
        jj = testframe;
        frame = img_crop(y_top:(y_top+inc),1:crop_w,jj);
        frameBF = img_cropBF(y_top:(y_top+inc),1:crop_w,jj);
        
        spacecount = 0;
        
        while Button < 2
            BWfinal2 = threshIt(frame,Thr_x);
            sjj = regionprops(BWfinal2, 'Area', 'centroid', 'BoundingBox','MajorAxisLength', 'MinorAxisLength', 'Eccentricity', 'Orientation');
            centroids = cat(1, sjj.Centroid);
            img_bw(:,:,jj) = BWfinal2;
            threshow = img_bw(:,:,jj);
            
            % First, set upipStart line for given pocket. Refer to getkey.m
            % (downloaded from online). Let user shift line until enter
            % is pressed.
            ch = 0;
            
            if spacecount < 1
                
                while ch ~= 13   % while enter hasn't been pressed yet
                    
                    figure(2)
                    set(gcf, 'Units', 'Normalized', 'OuterPosition', [0 0 1 1]);
                    
                    subplot(3,3,[2,5,8])
                    title('Use the LEFT and RIGHT arrow keys to adjust micropipette entrace (yellow line) and press ENTER when done.','fontsize', 20)
                    
                    subplot(3,3,[1,4,7])
                    imshow(img_cropBF(:,:,jj))
                    hold on
                    rectangle('Position',[0 y_top crop_w inc], 'EdgeColor', 'y', 'LineWidth', 3)
                    hold off
                    
                    subplot(3,3,6) % 2 rows, 1 column, plot #1
                    imshow(frame)
                    title('original','fontsize',20)
                    hold on
                    line([upipStart(kk), upipStart(kk)],[y1,y2],'Color','y','LineWidth',1)
                    hold off
                    
                    subplot(3,3,3)
                    imshow(frameBF)
                    hold on
                    line([upipStart(kk), upipStart(kk)],[y1,y2],'Color','y','LineWidth',1)
                    hold off
                    
                    subplot(3,3,9)
                    imshow(threshow)
                    title('thresholded','fontsize',20)
                    hold on
                    line([upipStart(kk), upipStart(kk)],[y1,y2],'Color','y','LineWidth',1)
                    hold off
                    
                    ch = getkey;
                    if ch == 28
                        upipStart(kk:18) = upipStart(kk)- 1;
                    end
                    if ch == 29
                        upipStart(kk:18) = upipStart(kk)+1;
                    end
                    spacecount = spacecount + 1;
                end
            end
            
            % upipStart should be set and unchanged after this point for
            % the given pocket
            
            button = 0;
            
            [nElements, BinCenters] = hist(double(frame), 60);   % Compute histogram of image intensity (using 60 bins)
            subplot(3,3,[2,5,8])
            bar(BinCenters, nElements); %axis tight          % Plot histogram
            %keep x-axis constant
            axis([min(min(frame)) 255 0 max(max(nElements))])
            %plot previous threshold values in histogram
            if kk > 1
                hold on
                for ki = 1:kk-1
%                     line([Thr_x_store(ki), Thr_x_store(ki)],[0,max(max(nElements))],'Color','b','LineWidth',1)
                end
                hold off
            end
            title('Pick pixel intensity threshold (LEFT button to preview, RIGHT button to save). The x-value where you RIGHT CLICK is what gets stored!', 'fontsize', 20)
            set(gca,'fontsize',16)
            xlabel('pixel intensity','fontsize',20)
            ylabel('pixel count','fontsize',20)
                        
            [x,y, Button]=ginput(1);    % Pick threshold from histogram (x-position)
            
            % If enter or some other key hit by mistake, show error (must
            % click mouse button and tell user to select threshold again
            while isempty(x) == 1
                [x,y, Button]=ginput(1);    % Pick threshold from histogram (x-position)
            end
            
            Thr_x = uint8(x);           % Convert into uint8 format
            
            Thr_x_store(kk) = Thr_x;
            
            % Apply proper threshold to each frame
            for tt = 1:stackSizeT
                
                prefinalFrame = img_crop(y_top:(y_top+inc),1:crop_w,tt);
                finalFrame(:,:,tt,kk) = threshIt(prefinalFrame,Thr_x_store(kk));
                
                % Visualize thresholding.
                if Button < 2 && rem(tt,nthFrame)== 0
                    % Newly added. want to visualize the centroid and bounding box
                    % during the frame simulation!
                    ffpretemp = finalFrame(:,:,tt,kk);
                    preR = regionprops(ffpretemp, 'Area', 'centroid', 'BoundingBox');
                    % If multiple centroids, choose the left-most one
                    pcentroids = cat(1, preR.Centroid);
                    
                    figure(2)
                    subplot(3,3,6)
                    imshow(img_crop(y_top:(y_top+inc),1:crop_w,tt))
                    title(['original:' num2str(tt, '%03i') ' of ' num2str(stackSizeT, '%03i')],'fontsize',20)
                    hold on
                    line([upipStart(kk), upipStart(kk)],[y1,y2],'Color','y','LineWidth',1)
                    if length(pcentroids)>0
                        line([preR(1).BoundingBox(1), preR(1).BoundingBox(1)],[y1,y2],'Color','r','LineWidth',1)
                    end
                    hold off
                    
                    subplot(3,3,3)
                    imshow(img_cropBF(y_top:(y_top+inc),1:crop_w,tt))
                    hold on
                    line([upipStart(kk), upipStart(kk)],[y1,y2],'Color','y','LineWidth',1)
                    hold off
                    
                    subplot(3,3,9)
                    imshow(finalFrame(:,:,tt,kk))
                    title('thresholded','fontsize',20)
                    hold on
                    line([upipStart(kk), upipStart(kk)],[y1,y2],'Color','y','LineWidth',1)
                    
                    if length(pcentroids)>0
                        plot(pcentroids(:,1),pcentroids(:,2), 'r*', 'LineWidth', 1,'MarkerSize', 8)
                    else
                    end
                    pnumcentroids = size(pcentroids);
                    for zz = 1:pnumcentroids(1)
                        rectangle('Position', [preR(zz).BoundingBox(1),preR(zz).BoundingBox(2),preR(zz).BoundingBox(3),preR(zz).BoundingBox(4)],'EdgeColor','r','LineWidth',1 )
                    end
                    hold off
                else
                end
            end
        end
        y_top = y_bottom;
    end
    
end

% After the images are properly thresholded, extract necessary information
% Go pocket by pocket. In Excel, export 'Pocket #1', etc...

% Initialize variables containing results
CenX = zeros(tt, kk);
CenY = zeros(tt, kk);
Area = zeros(tt, kk);
BBox_X1 = zeros(tt, kk);
BBox_X2 = zeros(tt, kk);

for kk = 1:18
    %Exclude events with threshold > 244
    if Thr_x_store(kk) > 244
        nucprotrusion(1:stackSizeT,kk) = 0;
    else
    %Analyze events with normal threshold
        for tt = 1:stackSizeT
            fftemp = finalFrame(:,:,tt,kk);
            if  mean(max(fftemp,[],1))>0
                R = regionprops(fftemp, 'Area', 'centroid', 'BoundingBox');
                % If multiple centroids, choose the left-most one
                CenX(tt,kk) = R(1).Centroid(1);   % R(1) only taking one centroid if multiple. Does it count left to right?
                CenY(tt,kk) = R(1).Centroid(2);
                BBox_X1(tt,kk) = R(1).BoundingBox(1);
                % BBox_X2(tt,kk) = R(1).BoundingBox(2);
                nucprotrusion(tt,kk) = (upipStart(kk) - BBox_X1(tt,kk))*Scale;
            else
            end
        end
    end
end

% Preceeding frame must be 0. implement counting index trigger = 0 and then
% becomes 1 on next one if not 0.
trigger = 0;
entranceFrame = zeros(kk);

nucP = nucprotrusion';  % Use to analyze

% Save to file
if positionSize == 1
    filename_xlsx = ['MPAresults_' name '.xlsx'];
else
    filename_xlsx = ['MPAresults_' name '_Pos' num2str(q, '%02i') '.tif'];
end


% If file already exists, ask if you want to save over or rename
%         col_header={};     %Row cell array (for column labels)
%         row_header()={};     %Column cell array (for row labels)
xlswrite(filename_xlsx,nucP,1,'B4');
%         xlswrite(filename_xlsx,col_header,'Sheet1','B3');     %Write column header
%         xlswrite(filename_xlsx,row_header,'Sheet1','A4');      %Write row header

close all;