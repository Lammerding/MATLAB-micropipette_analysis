function [threshout] = threshIt(threshin, orig)
BWs = threshin > orig;                  % threshold image
BWs = bwareaopen(BWs,100);              % remove all small areas
BWfill = imfill(BWs, 'holes');          % fill holes

% Remove areas touching the left border

% Start by padding the image with 1s on the left
pad = padarray(BWfill,[0 1],1,'pre');
% Remove objects touching the border of the padded image (left).
BWnobordpad = imclearborder(pad, 4);
% Remove the padded column
BWnobord = BWnobordpad(:,2:end);

% BWnobord = BWfill;

% erode image
seD = strel('diamond',1);   % create circular structure element for erosion with 2 pixel diameter:
BWfinal = imerode(BWnobord,seD);        % erode image to smooth boundaries and remove spurrious pixel
BWfinal2 = imdilate(BWfinal, seD);      % create smoothed binary image by dilating eroded image
           
BWoutline = bwperim(BWfinal);           % compute outlines of segmented image (nuclei)
BWoutline = imdilate(BWoutline, seD);   % expand outlines by dilation (2 pixel diameter) to be ~5 pixels wide                 
           
%           BWscale = 1;   % scale factor which is multiplied by the 'level' value from MATLABs graythresh funtion to threshold the binary image (default: 65)
pThresh = 50;     % objects smaller than n pixels will be removed from the image (default: 50)
%           closerad = 15;     % specifies a radius of n pixels to close gaps post thresholding (imclose function) function (default: 5)
%             
%           BW = im2bw(frame,level*BWscale);  %scales MATLABs auto 'level' value to help smooth the image
%           se = strel('disk',closerad); 
%           closeBW = imclose(BW,se);
threshout = bwareaopen(BWfinal2,pThresh);  %remove any features smaller than n pixels
end

      